﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    public partial class MainWindow : Window
    {
        SqlConnection conn = null;
        public MainWindow()
        {
            InitializeComponent();
            
            conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-94PNF80;Initial Catalog=Grocery;
            Integrated Security=True;Connect Timeout=5;Encrypt=False;TrustServerCertificate=False;
            ApplicationIntent=ReadWrite;MultiSubnetFailover=False;";
        }

        private void Connection_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conn.Open();
                MessageBox.Show("You are connected");
            }
            catch
            {
                MessageBox.Show("Connection Fail");
            }
        }

        private void Disconnection_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                conn.Close();
                MessageBox.Show("You are disconnected");
            }
            catch
            {
                MessageBox.Show("Connection Fail");
            }
        }

        private void Creation_Click(object sender, RoutedEventArgs e)
        {
            string query =
            @"CREATE TABLE VegetableFruit
                (
                    [Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                    [Name] NVARCHAR(MAX) NOT NULL CHECK([Name]!=''),
                    [Type] NVARCHAR(10) NOT NULL CHECK([Type]!=''),
                    [Color] NVARCHAR(20) NOT NULL CHECK([Color]!=''),
                    [Calory] INT NOT NULL DEFAULT 0
                );";

            SqlCommand cmd = new SqlCommand(query, conn);

            try
            {                
                cmd.ExecuteNonQuery();
                MessageBox.Show("Table Created Successfully");
            }
            catch
            {
                MessageBox.Show("Error");
            }
        }
    }
}
