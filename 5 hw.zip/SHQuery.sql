--CREATE DATABASE SecondHand;
USE SecondHand;

--CREATE TABLE Buyers(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,	
--	[SNP] NVARCHAR(MAX) NOT NULL CHECK([SNP]!=''),
--	[Birthdate] DATE NOT NULL CHECK([Birthdate]<=GETDATE()),
--	[Sex] NVARCHAR(10) NOT NULL CHECK([Sex]!=''),
--	[Mail] NVARCHAR(50) NOT NULL CHECK([Mail]!=''),
--	[Country] NVARCHAR(30) NOT NULL CHECK([Country]!=''),
--	[City] NVARCHAR(30) NOT NULL CHECK([City]!='')
--);

--CREATE TABLE Products(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,	
--	[Name] NVARCHAR(MAX) NOT NULL CHECK([Name]!='')
--);

--CREATE TABLE BuyersInterests(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,	
--	[BuyerId] INT NOT NULL FOREIGN KEY REFERENCES [Buyers](Id),
--	[ProductId] INT NOT NULL FOREIGN KEY REFERENCES [Products](Id)
--);

--CREATE TABLE Sales(
--	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
--	[ForCountry] NVARCHAR(30) NOT NULL CHECK([ForCountry]!=''),
--	[StartDate] DATE NOT NULL CHECK([StartDate]>=GETDATE()),
--	[EndDate] DATE NOT NULL CHECK([EndDate]>=GETDATE()),
--	[ProductId] INT NOT NULL FOREIGN KEY REFERENCES [Products](Id),
--	CHECK([EndDate] > [StartDate])
--);

--INSERT INTO Buyers VALUES('Aliyev Hafis Sanan', '1982-10-22', 'Male', 'afs@testmail.com', 'Azerbaijan', 'Baki');
--INSERT INTO Buyers VALUES('Kamilli Niyaz Sabir', '1987-11-03', 'Male', 'kns@testmail.com', 'Azerbaijan', 'Baki');
--INSERT INTO Buyers VALUES('Qurbanova Nigar Kanan', '1992-09-25', 'Female', 'qnk@testmail.com', 'Azerbaijan', 'Baki');
--INSERT INTO Buyers VALUES('Bayramov Anar Yaver', '1989-02-15', 'Male', 'bay@testmail.com', 'Azerbaijan', 'Baki');
--INSERT INTO Buyers VALUES('Sariyeva Sara Namiq', '1981-12-14', 'Female', 'ssn@testmail.com', 'Azerbaijan', 'Baki');
--INSERT INTO Buyers VALUES('Farhadova Nargiz Polad', '1994-10-14', 'Female', 'fnp@testmail.com', 'Azerbaijan', 'Baki');
--INSERT INTO Buyers VALUES('Hasanov Nazim Rafiq', '1984-11-03', 'Male', 'hnr@testmail.com', 'Azerbaijan', 'Baki');
--INSERT INTO Buyers VALUES('Nikolayev Oleg Mikailovich', '1981-01-28', 'Male', 'nom@testmail.com', 'Russia', 'Moscow');
--INSERT INTO Buyers VALUES('Afanasiyeva Svetlana Yuryevna', '1994-09-22', 'Female', 'asy@testmail.com', 'Russia', 'Leningrad');
--INSERT INTO Buyers VALUES('Stuart Thomas', '1982-12-14', 'Male', 'st@testmail.com', 'England', 'London');
--INSERT INTO Buyers VALUES('Gigs David', '1982-05-21', 'Male', 'gd@testmail.com', 'England', 'London');

--INSERT INTO Products VALUES('mobile phones');
--INSERT INTO Products VALUES('laptops');
--INSERT INTO Products VALUES('TV');
--INSERT INTO Products VALUES('furnitures');
--INSERT INTO Products VALUES('clothes');

--INSERT INTO BuyersInterests VALUES(1, 1);
--INSERT INTO BuyersInterests VALUES(1, 3);
--INSERT INTO BuyersInterests VALUES(1, 5);
--INSERT INTO BuyersInterests VALUES(2, 2);
--INSERT INTO BuyersInterests VALUES(2, 4);
--INSERT INTO BuyersInterests VALUES(3, 1);
--INSERT INTO BuyersInterests VALUES(4, 5);
--INSERT INTO BuyersInterests VALUES(5, 2);
--INSERT INTO BuyersInterests VALUES(6, 3);
--INSERT INTO BuyersInterests VALUES(7, 4);
--INSERT INTO BuyersInterests VALUES(8, 1);
--INSERT INTO BuyersInterests VALUES(9, 2);
--INSERT INTO BuyersInterests VALUES(10, 3);
--INSERT INTO BuyersInterests VALUES(11, 5);

--INSERT INTO Sales VALUES('Azerbaijan', '2022-06-21', '2022-06-30', 1);
--INSERT INTO Sales VALUES('Russia', '2022-06-23', '2022-06-28', 2);
--INSERT INTO Sales VALUES('England', '2022-06-22', '2022-06-29', 3);