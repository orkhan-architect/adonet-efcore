﻿using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;
using dapper1;


using IDbConnection connection = new SqlConnection("Data Source=DESKTOP-94PNF80;Initial Catalog=SecondHand;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

connection.Open();

var query1 = "SELECT * FROM Buyers";
var buyer_coll_1 = connection.Query<Buyer>(query1).ToList();

//foreach (var item in buyer_coll_1)
//    Console.WriteLine(item);

//foreach (var item in buyer_coll_1)
//    Console.WriteLine(item.Mail);

var query2 = "SELECT * FROM Products";
var prod_coll_1 = connection.Query<Product>(query2).ToList();
//foreach (var item in prod_coll_1)
//    Console.WriteLine(item);

var query3 = "SELECT * FROM Sales INNER JOIN Products ON Sales.ProductId=Products.Id";

var sale_coll_1 = connection.Query<Sale, Product, Sale>(query3, 
    (sales, products) => 
    {
        sales.Product = products;
        return sales;
    }, splitOn: "ProductId").ToList();

//foreach (var item in sale_coll_1)
//    Console.WriteLine(item.ForCountry + '\n' + item.StartDate + '\n' + item.EndDate + '\n' + item.Product.Name + '\n');

var query4 = "SELECT DISTINCT [Country] FROM Buyers";
var buyer_coll_4 = connection.Query<Buyer>(query4).ToList();
//foreach (var item in buyer_coll_4)
//    Console.WriteLine(item.Country);

var query5 = "SELECT DISTINCT [City] FROM Buyers";
var buyer_coll_5 = connection.Query<Buyer>(query5).ToList();
//foreach (var item in buyer_coll_5)
//    Console.WriteLine(item.City);

var query6 = "SELECT * FROM Buyers WHERE City='Baki'";
var buyer_coll_6 = connection.Query<Buyer>(query6).ToList();
//foreach (var item in buyer_coll_6)
//    Console.WriteLine(item);

var query7 = "SELECT * FROM Buyers WHERE Country='England'";
var buyer_coll_7 = connection.Query<Buyer>(query7).ToList();
//foreach (var item in buyer_coll_7)
//    Console.WriteLine(item);

var query8 = "SELECT * FROM Sales INNER JOIN Products ON Sales.ProductId=Products.Id WHERE ForCountry='Russia'";
var sale_coll_2 = connection.Query<Sale, Product, Sale>(query8,
    (sales, products) =>
    {
        sales.Product = products;
        return sales;
    }, splitOn: "ProductId").ToList();

//foreach (var item in sale_coll_2)
//    Console.WriteLine(item.ForCountry + '\n' + item.StartDate + '\n' + item.EndDate + '\n' + item.Product.Name + '\n');

connection.Close();