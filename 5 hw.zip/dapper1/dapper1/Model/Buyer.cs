﻿using System;
using System.Collections.Generic;

namespace dapper1
{
    public partial class Buyer
    {
        public Buyer()
        {
            BuyersInterests = new HashSet<BuyersInterest>();
        }

        public int Id { get; set; }
        public string Snp { get; set; } = null!;
        public DateTime Birthdate { get; set; }
        public string Sex { get; set; } = null!;
        public string Mail { get; set; } = null!;
        public string Country { get; set; } = null!;
        public string City { get; set; } = null!;

        public virtual ICollection<BuyersInterest> BuyersInterests { get; set; }

        public override string ToString()
        {
            return $"SNP: {Snp}\n" +
                $"Birthdate: {Birthdate}\n" +
                $"Sex: {Sex}\n" +
                $"Mail: {Mail}\n" +
                $"Country: {Country}\n" +
                $"City: {City}\n";
        }
    }
}
