﻿using System;
using System.Collections.Generic;

namespace dapper1
{
    public partial class BuyersInterest
    {
        public int Id { get; set; }
        public int BuyerId { get; set; }
        public int ProductId { get; set; }

        public virtual Buyer Buyer { get; set; } = null!;
        public virtual Product Product { get; set; } = null!;
    }
}
