﻿using System;
using System.Collections.Generic;

namespace dapper1
{
    public partial class Sale
    {
        public int Id { get; set; }
        public string ForCountry { get; set; } = null!;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int ProductId { get; set; }

        public virtual Product Product { get; set; } = null!;
    }
}
