﻿using System;
using System.Collections.Generic;

namespace dapper1
{
    public partial class Product
    {
        public Product()
        {
            BuyersInterests = new HashSet<BuyersInterest>();
            Sales = new HashSet<Sale>();
        }

        public int Id { get; set; }
        public string Name { get; set; } = null!;

        public virtual ICollection<BuyersInterest> BuyersInterests { get; set; }
        public virtual ICollection<Sale> Sales { get; set; }

        public override string ToString()
        {
            return $"Id: {Id}\n" +
                $"Product: {Name}\n";
        }
    }
}
