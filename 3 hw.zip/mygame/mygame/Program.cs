﻿using System;
using mygame;
using mygame.Model;
using Microsoft.EntityFrameworkCore;

using GameDbContext context = new();

//var new_company = new Company()
//{
//    Name = "UbiSoft"
//};
//context.Companies.Add(new_company);

//var new_companyList = new List<Company>()
//{
//    new Company() { Name = "Electronic Arts" },
//    new Company() { Name = "Blizzard" }
//};
//context.Companies.AddRange(new_companyList);

//var new_gameList = new List<Game>()
//{
//    new Game() { Name = "Far cry 5", CompanyId = 1, Genre="adventure", ReleaseDate=Convert.ToDateTime("2018.03.27") },
//    new Game() { Name = "Assassins creed", CompanyId = 1, Genre="action", ReleaseDate=Convert.ToDateTime("2020.11.10") },
//    new Game() { Name = "Battlefield V", CompanyId = 4, Genre="shooter", ReleaseDate=Convert.ToDateTime("2018.11.09") },
//    new Game() { Name = "Star wars", CompanyId = 4, Genre="adventure", ReleaseDate=Convert.ToDateTime("2011.12.20") },
//    new Game() { Name = "Call of duty 2", CompanyId = 5, Genre="shooter", ReleaseDate=Convert.ToDateTime("2005.10.25") },
//    new Game() { Name = "Tony Hawks", CompanyId = 5, Genre="sport", ReleaseDate=Convert.ToDateTime("1999.09.29") }
//};
//context.Games.AddRange(new_gameList);

//context.SaveChanges();

var created_games = context.Games.Include(x=>x.Company);

Console.WriteLine("ID: Game, -- Genre, -- ReleaseDate, -- Company Name");
Console.WriteLine();

foreach (var item in created_games)
{
    Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name}");
}