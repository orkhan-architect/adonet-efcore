﻿using System;
using mygame;
using mygame.Model;
using Microsoft.EntityFrameworkCore;

using GameDbContext context = new();

//var new_company = new Company()
//{
//    Name = "UbiSoft"
//};
//context.Companies.Add(new_company);

//var new_companyList = new List<Company>()
//{
//    new Company() { Name = "Electronic Arts" },
//    new Company() { Name = "Blizzard" }
//};
//context.Companies.AddRange(new_companyList);

//var new_gameList = new List<Game>()
//{
//    new Game() { Name = "Far cry 5", CompanyId = 1, Genre="adventure", ReleaseDate=Convert.ToDateTime("2018.03.27") },
//    new Game() { Name = "Assassins creed", CompanyId = 1, Genre="action", ReleaseDate=Convert.ToDateTime("2020.11.10") },
//    new Game() { Name = "Battlefield V", CompanyId = 4, Genre="shooter", ReleaseDate=Convert.ToDateTime("2018.11.09") },
//    new Game() { Name = "Star wars", CompanyId = 4, Genre="adventure", ReleaseDate=Convert.ToDateTime("2011.12.20") },
//    new Game() { Name = "Call of duty 2", CompanyId = 5, Genre="shooter", ReleaseDate=Convert.ToDateTime("2005.10.25") },
//    new Game() { Name = "Tony Hawks", CompanyId = 5, Genre="sport", ReleaseDate=Convert.ToDateTime("1999.09.29") }
//};
//context.Games.AddRange(new_gameList);
//context.SaveChanges();

string searchedGameName = "Star wars";
string searchedCompanyName = "Electronic Arts";
string searchedGenre = "shooter";
DateTime searchedReleaseDate = Convert.ToDateTime("2020.11.10");

var created_games = context.Games.Include(x=>x.Company);

Console.WriteLine("ID: Game, -- Genre, -- ReleaseDate, -- Company Name \n");

#region First_part_of_HW
//foreach (var item in created_games)
//{
//    if (item.Name == searchedGameName)
//        Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name}");
//}

//foreach (var item in created_games)
//{
//    if (item.Company.Name == searchedCompanyName)
//        Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name}");
//}

//foreach (var item in created_games)
//{
//    if (item.Name == searchedGameName && item.Company.Name == searchedCompanyName)
//        Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name}");
//}

//foreach (var item in created_games)
//{
//    if (item.Genre == searchedGenre)
//        Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name}");
//}

//foreach (var item in created_games)
//{
//    if (item.ReleaseDate == searchedReleaseDate)
//        Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name}");
//}
#endregion

#region Second_part_of_HW
//foreach (var item in created_games)
//{
//    if (item.PlayerForm == "single")
//        Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name} --{item.PlayerForm}");
//}

//foreach (var item in created_games)
//{
//    if (item.PlayerForm == "multiple")
//        Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name} --{item.PlayerForm}");
//}

var descend_list = created_games.OrderByDescending(x=>x.SelledCopies);
//foreach (var item in descend_list)
//{    
//    Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name} --{item.SelledCopies} copies");
//    break;
//}

//int i = 0;
//foreach (var item in descend_list)
//{
//    Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name} --{item.SelledCopies} copies");
//    i++;
//    if (i == 3)
//        break;
//}

var ascend_list = created_games.OrderBy(x => x.SelledCopies);
//foreach (var item in ascend_list)
//{
//    Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name} --{item.SelledCopies} copies");
//    break;
//}

//int j = 0;
//foreach (var item in ascend_list)
//{
//    Console.WriteLine($"{item.Id}: {item.Name},-- {item.Genre},-- {item.ReleaseDate}, --{item.Company.Name} --{item.SelledCopies} copies");
//    j++;
//    if (j == 3)
//        break;
//}
#endregion

#region Third_part_of_HW
bool IsUnique = true;
string newGame1 = "Star wars";//for unique checking
string newGame2 = "Watch Dogs";

//foreach (var item in created_games)
//{
//    if (item.Name.Contains(newGame2))
//    {
//        IsUnique = false;
//        break;
//    }
//}

//if (!IsUnique)
//{
//    Console.WriteLine("You have this game in your db");
//}
//else
//{
//    context.Games.Add(
//        new Game() { Name = newGame2, CompanyId = 1, Genre = "adventure", ReleaseDate = Convert.ToDateTime("2014.05.27"), PlayerForm = "single", SelledCopies = 1400 }
//        );
//    context.SaveChanges();
//    Console.WriteLine("You added new game to your db");
//}

//context.Games.Add(
//    new Game() { Name = "tes1", CompanyId = 1, Genre = "adventure", ReleaseDate = Convert.ToDateTime("2014.05.27"), PlayerForm = "single", SelledCopies = 1400 }
//    );
//context.Games.Add(
//    new Game() { Name = "tes2", CompanyId = 1, Genre = "adventure", ReleaseDate = Convert.ToDateTime("2014.05.27"), PlayerForm = "single", SelledCopies = 1400 }
//    );
//context.SaveChanges();

//// I can change any column by this way
//var updating1 = context.Games.FirstOrDefault(x => x.Id == 1);
//if (updating1 != null)
//    updating1.PlayerForm = "multiple";
//context.SaveChanges();

string gameName_onDelete = "tes2";
int companyId_onDelete = 1;
int gameID_onDelete = 0;
bool delete_checking = true;

//foreach (var item in created_games)
//{
//    if (item.Name.Contains(gameName_onDelete) && item.CompanyId== companyId_onDelete)
//    {
//        gameID_onDelete = item.Id;
//        break;
//    }
//}

//if (delete_checking)
//    context.Remove(context.Games.ToList().Find(x => x.Id == gameID_onDelete));

//context.SaveChanges();

#endregion