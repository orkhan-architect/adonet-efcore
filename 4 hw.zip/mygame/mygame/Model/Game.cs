﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mygame.Model
{
    public class Game
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [StringLength(15)]
        public string Name { get; set; }

        [Required]
        public int CompanyId { get; set; }

        [Required]
        [StringLength(15)]
        public string Genre { get; set; }
        public DateTime ReleaseDate { get; set; }

        public virtual Company Company { get; set; } = null!;

        [Required]
        [StringLength(10)]
        public string PlayerForm { get; set; }

        [Required]
        public int SelledCopies { get; set; }
    }
}
