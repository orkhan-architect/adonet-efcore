using System;
using System.Reflection;
using WinFormsApp1;
using Microsoft.EntityFrameworkCore;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        AcademyContext context = new();

        public Form1()
        {
            InitializeComponent();            
        }

        private void GetDataBTN_Click(object sender, EventArgs e)
        {
            DbGridView.DataSource = context.Teachers.ToList();
        }

        private void UpdateBTN_Click(object sender, EventArgs e)
        {
            context.Teachers.UpdateRange();
            context.SaveChanges();
        }
    }
}