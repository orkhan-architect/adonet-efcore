﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GetDataBTN = new System.Windows.Forms.Button();
            this.UpdateBTN = new System.Windows.Forms.Button();
            this.DbGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.DbGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // GetDataBTN
            // 
            this.GetDataBTN.Location = new System.Drawing.Point(12, 26);
            this.GetDataBTN.Name = "GetDataBTN";
            this.GetDataBTN.Size = new System.Drawing.Size(75, 23);
            this.GetDataBTN.TabIndex = 0;
            this.GetDataBTN.Text = "Get Data";
            this.GetDataBTN.UseVisualStyleBackColor = true;
            this.GetDataBTN.Click += new System.EventHandler(this.GetDataBTN_Click);
            // 
            // UpdateBTN
            // 
            this.UpdateBTN.Location = new System.Drawing.Point(767, 26);
            this.UpdateBTN.Name = "UpdateBTN";
            this.UpdateBTN.Size = new System.Drawing.Size(110, 23);
            this.UpdateBTN.TabIndex = 1;
            this.UpdateBTN.Text = "Update Data";
            this.UpdateBTN.UseVisualStyleBackColor = true;
            this.UpdateBTN.Click += new System.EventHandler(this.UpdateBTN_Click);
            // 
            // DbGridView
            // 
            this.DbGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DbGridView.Location = new System.Drawing.Point(12, 55);
            this.DbGridView.Name = "DbGridView";
            this.DbGridView.RowTemplate.Height = 25;
            this.DbGridView.Size = new System.Drawing.Size(865, 383);
            this.DbGridView.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 450);
            this.Controls.Add(this.DbGridView);
            this.Controls.Add(this.UpdateBTN);
            this.Controls.Add(this.GetDataBTN);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.DbGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Button GetDataBTN;
        private Button UpdateBTN;
        private DataGridView DbGridView;
    }
}