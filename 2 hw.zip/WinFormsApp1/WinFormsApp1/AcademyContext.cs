﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace WinFormsApp1
{
    public partial class AcademyContext : DbContext
    {
        public AcademyContext()
        {
        }

        public AcademyContext(DbContextOptions<AcademyContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Assistant> Assistants { get; set; } = null!;
        public virtual DbSet<Curator> Curators { get; set; } = null!;
        public virtual DbSet<Dean> Deans { get; set; } = null!;
        public virtual DbSet<Department> Departments { get; set; } = null!;
        public virtual DbSet<Faculty> Faculties { get; set; } = null!;
        public virtual DbSet<Group> Groups { get; set; } = null!;
        public virtual DbSet<GroupsCurator> GroupsCurators { get; set; } = null!;
        public virtual DbSet<GroupsLecture> GroupsLectures { get; set; } = null!;
        public virtual DbSet<Head> Heads { get; set; } = null!;
        public virtual DbSet<Lecture> Lectures { get; set; } = null!;
        public virtual DbSet<LectureRoom> LectureRooms { get; set; } = null!;
        public virtual DbSet<Schedule> Schedules { get; set; } = null!;
        public virtual DbSet<Subject> Subjects { get; set; } = null!;
        public virtual DbSet<Teacher> Teachers { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=DESKTOP-94PNF80;Initial Catalog=Academy;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Assistant>(entity =>
            {
                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.Assistants)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Assistant__Teach__34C8D9D1");
            });

            modelBuilder.Entity<Curator>(entity =>
            {
                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.Curators)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Curators__Teache__37A5467C");
            });

            modelBuilder.Entity<Dean>(entity =>
            {
                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.Deans)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Deans__TeacherId__3A81B327");
            });

            modelBuilder.Entity<Department>(entity =>
            {
                entity.HasIndex(e => e.Name, "UQ__Departme__737584F637990BC7")
                    .IsUnique();

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Faculty)
                    .WithMany(p => p.Departments)
                    .HasForeignKey(d => d.FacultyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Departmen__Facul__4F7CD00D");

                entity.HasOne(d => d.Head)
                    .WithMany(p => p.Departments)
                    .HasForeignKey(d => d.HeadId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Departmen__HeadI__5070F446");
            });

            modelBuilder.Entity<Faculty>(entity =>
            {
                entity.HasIndex(e => e.Name, "UQ__Facultie__737584F6159E7C7B")
                    .IsUnique();

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Dean)
                    .WithMany(p => p.Faculties)
                    .HasForeignKey(d => d.DeanId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Faculties__DeanI__4316F928");
            });

            modelBuilder.Entity<Group>(entity =>
            {
                entity.HasIndex(e => e.Name, "UQ__Groups__737584F620F8F441")
                    .IsUnique();

                entity.Property(e => e.Name).HasMaxLength(10);

                entity.HasOne(d => d.Department)
                    .WithMany(p => p.Groups)
                    .HasForeignKey(d => d.DepartmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Groups__Departme__5629CD9C");
            });

            modelBuilder.Entity<GroupsCurator>(entity =>
            {
                entity.HasOne(d => d.Curator)
                    .WithMany(p => p.GroupsCurators)
                    .HasForeignKey(d => d.CuratorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__GroupsCur__Curat__59063A47");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.GroupsCurators)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__GroupsCur__Group__59FA5E80");
            });

            modelBuilder.Entity<GroupsLecture>(entity =>
            {
                entity.HasOne(d => d.Group)
                    .WithMany(p => p.GroupsLectures)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__GroupsLec__Group__5CD6CB2B");

                entity.HasOne(d => d.Lecture)
                    .WithMany(p => p.GroupsLectures)
                    .HasForeignKey(d => d.LectureId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__GroupsLec__Lectu__5DCAEF64");
            });

            modelBuilder.Entity<Head>(entity =>
            {
                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.Heads)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Heads__TeacherId__3D5E1FD2");
            });

            modelBuilder.Entity<Lecture>(entity =>
            {
                entity.HasOne(d => d.Subject)
                    .WithMany(p => p.Lectures)
                    .HasForeignKey(d => d.SubjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Lectures__Subjec__30F848ED");

                entity.HasOne(d => d.Teacher)
                    .WithMany(p => p.Lectures)
                    .HasForeignKey(d => d.TeacherId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Lectures__Teache__31EC6D26");
            });

            modelBuilder.Entity<LectureRoom>(entity =>
            {
                entity.HasIndex(e => e.Name, "UQ__LectureR__737584F646BD8D32")
                    .IsUnique();

                entity.Property(e => e.Name).HasMaxLength(10);
            });

            modelBuilder.Entity<Schedule>(entity =>
            {
                entity.HasOne(d => d.Lecture)
                    .WithMany(p => p.Schedules)
                    .HasForeignKey(d => d.LectureId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Schedules__Lectu__48CFD27E");

                entity.HasOne(d => d.LectureRoom)
                    .WithMany(p => p.Schedules)
                    .HasForeignKey(d => d.LectureRoomId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Schedules__Lectu__49C3F6B7");
            });

            modelBuilder.Entity<Subject>(entity =>
            {
                entity.HasIndex(e => e.Name, "UQ__Subjects__737584F657F5E62B")
                    .IsUnique();

                entity.Property(e => e.Name).HasMaxLength(100);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
